$(document).ready (function () {
	$.ajax({
		type : 'GET',
		url : 'PhoneInformation.do',
		dataType : 'json',
		success : function(json) {
			var phone = json;
			
			$("#MainPhoneInfo").append($("<div class='phoneTitle'><span class='phoneTitle model'>"+phone.Brand+' ' +phone.Model+"</span>" +
					"<span class='phoneTitle os'>Android "+phone.version+"</span>"+
					"<span class='phoneTitle number'>"+phone.phoneNum+"</span>"+
					"</div>"));		
			}
		});
});