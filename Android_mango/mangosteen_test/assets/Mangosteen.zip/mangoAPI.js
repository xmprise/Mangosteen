var mangoAPI = {
	version : "0.1",
};